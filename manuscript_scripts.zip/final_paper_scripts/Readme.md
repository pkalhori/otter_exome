These are the scripts used for the manuscript "Genomic analyses reveal range-wide devastation of sea otter populations"

The scripts for demographic inference, including all template and estimation files for the models, as well as the site frequency spectrum for each population, is found under "fastsimcoal_final"

Scripts for the simulations done in SLiM are in the "SLIM_final" scripts with the corresponding populations and models, as well as scripts for concatenating the results.

